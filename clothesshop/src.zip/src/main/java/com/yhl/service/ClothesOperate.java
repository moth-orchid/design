package com.yhl.service;

import org.springframework.stereotype.Service;

@Service
public class ClothesOperate implements ClothesSelect{

}
