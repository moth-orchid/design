package com.yhl.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ClothesController {
	
}
